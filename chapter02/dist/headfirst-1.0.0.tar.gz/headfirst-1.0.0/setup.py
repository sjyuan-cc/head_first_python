from distutils.core import setup

setup(
    name='headfirst',
    version='1.0.0',
    py_modules=['headerfirst'],
    author='sjyuan',
    author_email='sjyuan@thoughtworks.com',
    url='http://blog.csdn.net/ysjian_pingcx',
    description='A simple printer of nested lists',
)
